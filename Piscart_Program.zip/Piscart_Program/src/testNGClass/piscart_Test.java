package testNGClass;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import buisnessMethods.BlogsPage_imageValidation;
import buisnessMethods.PiscartPage_Validation;
import factoryClass.Blogs_Page;
import reUsable_Methods.Driver;

public class piscart_Test {
	
	PiscartPage_Validation piscart_vd = new PiscartPage_Validation();
	BlogsPage_imageValidation blogs = new BlogsPage_imageValidation();
	
	@BeforeSuite
	public void openBrowser() {
		Driver.DRIVER.get("https://picsart.com/");
	}

	@Test
	public void piscartLogin() {
		piscart_vd.validate_UserIsLoggedIn("https://picsart.com/create/", "https://picsart.com/");
	}
	
	@Test
	public void validate_buttons(){
		piscart_vd.validate_blogsURL("https://picsart.com/blog/");
		piscart_vd.validate_DesignSchoolURL("https://picsart.com/blog/category/design-school/");
		piscart_vd.validate_trendsURL("https://picsart.com/blog/category/trends/");
		piscart_vd.validate_piscartProURL("https://picsart.com/blog/category/picsart-pro/");
		piscart_vd.validate_newsURL("https://picsart.com/blog/category/news/");
	}
	
	@Test
	public void validate_SearchFunction(){
		piscart_vd.validate_Search("Meet Curator Ben Coffman: Explorer of the American Wilderness");
	}
	
	@Test
	public void validate_BlogsImage(){
		blogs.validateBlogsImage("https://picsart.com/blog/post/");
	}
	
	@AfterTest
	public void closeBrowser(){
		Driver.DRIVER.quit();
	}
}
