package reUsable_Methods;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


/**
 * Wait Statement.
 *
 */
public class TimeOut {

    /**
     * ImplicitWait.
     *
     * @param pTime time
     */
    public void implictWait(int pTime) {

        Driver.DRIVER.manage().timeouts().implicitlyWait(pTime, TimeUnit.SECONDS);

    }

    /**
     * Explicit Wait.
     *
     * @param pTime Time
     * @param pElement WebElement
     */
    public void explicitWait(int pTime, WebElement pElement) {

        WebDriverWait lWWait = new WebDriverWait(Driver.DRIVER, pTime);

        lWWait.until(ExpectedConditions.elementToBeClickable(pElement));

    }

    /**
     * Constant Time.
     *
     * @param pTime time
     * @throws InterruptedException the interrupted exception
     */
    public void constantWait(int pTime) throws InterruptedException {

        Thread.sleep(pTime);
    }

}
