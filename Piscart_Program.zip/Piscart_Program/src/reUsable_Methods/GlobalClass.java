package reUsable_Methods;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.testng.log4testng.Logger;

/**
 * Global class.
 *
 */
public class GlobalClass {

    /** prop. */
    private static Properties staticProp;

    /** The Constant BROWSER. */
    public static final String CHROMEBROWSER;

    /** The Constant BROWSERADDRESS. */
    public static final String DRIVERADDRESS;

    /** Application Url. */
    public static final String APPLICATIONURL;

    /** Screenshot Address. */
    public static final String SCREENSHOTADD;

    static {
        try {
            loadApplicationProerties();
        }
        catch (Exception e) {
            System.out.printf("Error", e);
        }

        CHROMEBROWSER = staticProp.getProperty("browser");

        DRIVERADDRESS = staticProp.getProperty("driverAdd");

        APPLICATIONURL = staticProp.getProperty("applicationURL");

        SCREENSHOTADD = staticProp.getProperty("SreenShotAdd");

    }

    /**
     * load Application Proerties.
     *
     * @return Property file data
     */
    public static Properties loadApplicationProerties() {
        staticProp = new Properties();
        InputStream lInput = null;

        try {

            String lFilename = "data.properties";
            lInput = GlobalClass.class.getClassLoader().getResourceAsStream(lFilename);
            if (lInput == null) {
                Logger.getLogger(GlobalClass.class).info("Unable to found Property class");
            }

            // load a properties file from class path, inside static method
            staticProp.load(lInput);

        }
        catch (IOException e) {
            System.out.printf("Error", e);
        }
        finally {
            if (lInput != null) {
                try {
                    lInput.close();
                }
                catch (IOException e) {
                    System.out.printf("Error", e);
                }
            }
        }
        return staticProp;
    }

}
