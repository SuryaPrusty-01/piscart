package reUsable_Methods;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;


/**
 * common methods.
 *
 */
public class CommonMethods {

    /**
     * DropDown code .
     *
     * @param pElement webelement
     * @param pVisibleText dropdownText
     */
	Actions lAct;
	Select Sel;
	
    public void dropDown(WebElement pElement, String pVisibleText) {

        Sel = new Select(pElement);

        Sel.selectByVisibleText(pVisibleText);

    }

    /**
     * Drop down by index.
     *
     * @param pElement the element
     * @param pIndex the index
     */
    public void dropDownByIndex(WebElement pElement, int pIndex) {

        Sel = new Select(pElement);

        Sel.selectByIndex(pIndex);

    }

    /**
     * Move to Element code.
     *
     * @param pElement webelement
     */
    public void moveToElement(WebElement pElement) {

        lAct = new Actions(Driver.DRIVER);

        lAct.moveToElement(pElement).click().build().perform();
    }

    /**
     * Double Click.
     *
     * @param pElement webelement
     */
    public void doubleClick(WebElement pElement) {

         lAct = new Actions(Driver.DRIVER);

        lAct.moveToElement(pElement).doubleClick().build().perform();

    }

    /**
     * Drag ndrop.
     *
     * @param pElement1 the element1
     * @param pElement2 the element2
     */
    public void dragNdrop(WebElement pElement1, WebElement pElement2) {

        lAct = new Actions(Driver.DRIVER);

        lAct.clickAndHold(pElement1).build().perform();

        lAct.moveToElement(pElement2).build().perform();

        lAct.release(pElement2).build().perform();

    }

    /**
     * Right click.
     *
     * @param pElement webelement
     */
    public void contextClick(WebElement pElement) {

        Actions lAct = new Actions(Driver.DRIVER);

        lAct.moveToElement(pElement).contextClick().build().perform();

    }
    
    /**
     * Enter action.
     */
    public void enterAction() {

        lAct = new Actions(Driver.DRIVER);
        
        lAct.sendKeys(Keys.ENTER).build().perform();

    }

    /**
     * Switch frame.
     *
     * @param pErameId the erame id
     */
    public void switchFrame(String pErameId) {

        Driver.DRIVER.switchTo().frame(pErameId);
    }

    /**
     * Switch default content.
     */
    public void switchDefaultContent() {

        Driver.DRIVER.switchTo().defaultContent();
    }
}
