package reUsable_Methods;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.io.Files;

public class reusbaleCode {

	public void explicitWait(int pTime, WebElement pElement) {

		WebDriverWait lWWait = new WebDriverWait(Driver.DRIVER, pTime);

		lWWait.until(ExpectedConditions.visibilityOf(pElement));
	}

	public void implicitWait(int time) {
		Driver.DRIVER.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
	}
	
	public void selectDropdown(WebElement ele, String value){
		Select sel = new Select(ele);
		sel.deselectByVisibleText(value);
	}

	public void eScreenShot(String pName) throws IOException, InterruptedException {

		File lScrFile = ((TakesScreenshot) Driver.DRIVER).getScreenshotAs(OutputType.FILE);
		Files.copy(lScrFile, new File(GlobalClass.SCREENSHOTADD + pName + ".png"));
	}
}
