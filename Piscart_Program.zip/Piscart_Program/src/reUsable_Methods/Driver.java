package reUsable_Methods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Driver {
	
	static {
	    
		System.setProperty(GlobalClass.CHROMEBROWSER,GlobalClass.DRIVERADDRESS);
	    }

	    
	    public static final WebDriver DRIVER = new ChromeDriver();
	
}