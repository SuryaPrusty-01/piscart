package factoryClass;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PiscartPage {
	
	@FindBy(xpath = "//img[@title='Picsart']")
	private WebElement Picsart_LogoLink;
	
	public WebElement getPicsart_LogoLink() {
		return Picsart_LogoLink;
	}

	@FindBy(xpath = "//button[@data-test='login-button']")
	private WebElement login_page_btn;
	
	@FindBy(name = "username")
	private WebElement username_txtbox;
	
	@FindBy(name = "password")
	private WebElement password_txtbox;
	
	@FindBy(xpath = "//button[@type='submit']")
	private WebElement login_btn;
	
	@FindBy(xpath="//strong[text()='Learn']")
	private WebElement learn_Link;
	
	@FindBy(name = "blog")
	private WebElement blog_btn;
	
	@FindBy(linkText = "design-school")
	private WebElement designschool_btn;
	
	@FindBy(linkText = "trends")
	private WebElement trends_btn;
	
	@FindBy(linkText = "picsart-pro")
	private WebElement picsartpro_btn;
	
	@FindBy(linkText = "news")
	private WebElement news_btn;
	
	@FindBy(xpath = "//button[contains(@class,'searchButton')]")
	private WebElement search_Btn;
	
	@FindBy(xpath = "//div[contains(@class,'masonry-vertical-column')]//p")
	private List<WebElement> searchResult;
	
	public WebElement getSearch_Btn() {
		return search_Btn;
	}

	public List<WebElement> getSearchResult() {
		return searchResult;
	}

	public WebElement getSearchTextbox() {
		return searchTextbox;
	}

	@FindBy(name = "search")
	private WebElement searchTextbox;

	public WebElement getLogin_page_btn() {
		return login_page_btn;
	}

	public WebElement getUsername_txtbox() {
		return username_txtbox;
	}

	public WebElement getPassword_txtbox() {
		return password_txtbox;
	}

	public WebElement getLogin_btn() {
		return login_btn;
	}

	public WebElement getLearn_Link() {
		return learn_Link;
	}

	public WebElement getBlog_btn() {
		return blog_btn;
	}

	public WebElement getDesignschool_btn() {
		return designschool_btn;
	}

	public WebElement getTrends_btn() {
		return trends_btn;
	}

	public WebElement getPicsartpro_btn() {
		return picsartpro_btn;
	}

	public WebElement getNews_btn() {
		return news_btn;
	}
	
	
		 

}
