package factoryClass;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Blogs_Page {
	
	@FindBy(xpath = "//div[contains(@class,'active')]/a")
	private WebElement active_image;
	
	@FindBy(xpath = "//button[contains(@class,'right')]/i")
	private WebElement rightArrowBtn;
	
	@FindBy(xpath = "//button[contains(@class,'left')]/i")
	private WebElement leftArrowBtn;

	public WebElement getActive_image() {
		return active_image;
	}

	public WebElement getRightArrowBtn() {
		return rightArrowBtn;
	}

	public WebElement getLeftArrowBtn() {
		return leftArrowBtn;
	}

	
}
