package buisnessMethods;

import org.testng.Assert;

import factoryClass.Blogs_Page;
import reUsable_Methods.CommonMethods;
import reUsable_Methods.Driver;

public class BlogsPage_imageValidation {
	
	Blogs_Page blg_page = new Blogs_Page();
	CommonMethods cmnMethods = new CommonMethods();
	
	public void validateBlogsImage(String expectedURL){
		cmnMethods.moveToElement(blg_page.getActive_image());
		boolean leftFlag = blg_page.getLeftArrowBtn().isDisplayed();
		if(!leftFlag){
			Assert.fail();
		}
		boolean rightFlag = blg_page.getRightArrowBtn().isDisplayed();
		if(!rightFlag){
			Assert.fail();
		}
		blg_page.getActive_image().click();
		String ImageURL = Driver.DRIVER.getCurrentUrl();
		if(!ImageURL.contains(expectedURL)){
			Assert.fail();
		}
	}

}
