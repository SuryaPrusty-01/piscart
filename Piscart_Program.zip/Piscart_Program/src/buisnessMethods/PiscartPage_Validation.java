package buisnessMethods;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.log4testng.Logger;
import factoryClass.PiscartPage;
import reUsable_Methods.CommonMethods;
import reUsable_Methods.Driver;
import reUsable_Methods.TimeOut;

public class PiscartPage_Validation {

	/** The Constant LOGGER. */
	static final Logger LOGGER = Logger.getLogger(PiscartPage_Validation.class);
	

	PiscartPage pic_page = new PiscartPage();
	CommonMethods cmnMethods = new CommonMethods();

	public void validate_UserIsLoggedIn(String LoggedInURL, String LoggedoutURL) {
		try {
			pic_page.getPicsart_LogoLink().click();
			String URL = Driver.DRIVER.getCurrentUrl();
			if(URL.equalsIgnoreCase(LoggedInURL)){
				LOGGER.info("User is logged in");
			}else if(URL.equalsIgnoreCase(LoggedoutURL)){
				LOGGER.info("User is logged out");
			}else{
				LOGGER.info("Unknown URL Navigating");
			}
		} catch (Exception e) {
			LOGGER.info("Not able to validate the URLS");
		}
	}
	
	public void validate_blogsURL(String Blogs_URL){
		cmnMethods.moveToElement(pic_page.getLearn_Link());
		pic_page.getBlog_btn().click();
		String URL = Driver.DRIVER.getCurrentUrl();
		if(URL.equalsIgnoreCase(Blogs_URL)){
			LOGGER.info("Successfully navigated to blogs Page");
		}else{
			LOGGER.info("unSuccessfully navigation");
		}
	}
	
	public void validate_DesignSchoolURL(String DesignSchool_URL){
		pic_page.getDesignschool_btn().click();
		String URL = Driver.DRIVER.getCurrentUrl();
		if(URL.equalsIgnoreCase(DesignSchool_URL)){
			LOGGER.info("Successfully navigated to DesignSchool Page");
		}else{
			LOGGER.info("unSuccessfully navigation");
		}
	}
	public void validate_trendsURL(String Trends_URL){
		pic_page.getTrends_btn().click();
		String URL = Driver.DRIVER.getCurrentUrl();
		if(URL.equalsIgnoreCase(Trends_URL)){
			LOGGER.info("Successfully navigated to trends Page");
		}else{
			LOGGER.info("unSuccessfully navigation");
		}
	}
	public void validate_piscartProURL(String piscartProURL){
		pic_page.getPicsartpro_btn().click();
		String URL = Driver.DRIVER.getCurrentUrl();
		if(URL.equalsIgnoreCase(piscartProURL)){
			LOGGER.info("Successfully navigated to piscart pro Page");
		}else{
			LOGGER.info("unSuccessfully navigation");
		}
	}
	public void validate_newsURL(String newsProURL){
		pic_page.getNews_btn().click();
		String URL = Driver.DRIVER.getCurrentUrl();
		if(URL.equalsIgnoreCase(newsProURL)){
			LOGGER.info("Successfully navigated to news Page");
		}else{
			LOGGER.info("unSuccessfully navigation");
		}
	}
	
	public void validate_Search(String Searchtext){
		cmnMethods.moveToElement(pic_page.getSearch_Btn());
		pic_page.getSearchTextbox().sendKeys(Searchtext);
		pic_page.getSearch_Btn().click();
		List<WebElement> searchResult = pic_page.getSearchResult();
		for (WebElement webElement : searchResult) {
			if(!webElement.getText().equalsIgnoreCase(Searchtext)){
				Assert.fail();
			}
		}
	}
}
